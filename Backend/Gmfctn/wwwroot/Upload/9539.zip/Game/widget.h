#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QDesktopWidget>
#include <QGraphicsScene>
#include <QGraphicsItem>
#include <QShortcut>
#include <QDebug>
#include <QTimer>
#include <QMessageBox>
#include <QMediaPlayer>
#include <QMediaPlaylist>

#include <fly.h>
#include <apple.h>
#include <spider.h>

//Константы игры
#define GAME_STOPED 0
#define GAME_STARTED 1
#define MAX_APPLES 100

namespace Ui { class Widget; }

class Widget : public QWidget {
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

private:
    Ui::Widget      *ui;
    QGraphicsScene  *scene;     // Объявляем графическую сцену
    Fly        *fly;  // и спрайт мухи
    QTimer          *timer;     // Таймер для управления мухой
    QTimer          *timerCreateApple;  // Таймер для периодического создания яблок в игре
    QList<QGraphicsItem *> apples;  // Список со всеми яблоками в игре
    double count;   // Счёт игры
    Spider          *spider;        // Паук
    QShortcut       *pauseKey;      // Клавиша "пауза"
    int             gameState;      // Состояние игры, GAME_STARTED или GAME_STOPED

private slots:
    void slotDeleteApple(QGraphicsItem * item); // Слот для удаления съеденных яблок
    void slotCreateApple();     // Слот для создания яблок по таймеру
    void on_pushButton_clicked();               // Слот для запуска игры
    void slotGameOver();                        // Слот для выхода из игры
    void slotPause();                           // Слот для обработки паузы
};

#endif // WIDGET_H
